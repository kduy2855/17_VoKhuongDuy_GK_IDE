import psycopg2
import os
import requests
from datetime import datetime

def create_table(conn):
    """Create the cat_breeds table if it doesn't exist"""
    create_table_sql = """
    CREATE TABLE IF NOT EXISTS cat_breeds (
        id VARCHAR(50) PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        origin VARCHAR(100),
        temperament TEXT[],
        life_span VARCHAR(50),
        image_url TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP
    );
    """
    with conn.cursor() as cursor:
        cursor.execute(create_table_sql)
        conn.commit()

def download_image(image_url, file_path):
    """Download and save cat image to local directory"""
    try:
        response = requests.get(image_url, stream=True, timeout=30)
        response.raise_for_status()
        with open(file_path, 'wb') as f:
            for chunk in response.iter_content(1024):
                f.write(chunk)
        return True
    except Exception as e:
        print(f"Failed to download image: {e}")
        return False

def save_to_database(conn, cat_data):
    """Save transformed cat data to PostgreSQL"""
    with conn.cursor() as cursor:
        upsert_sql = """
        INSERT INTO cat_breeds 
            (id, name, origin, temperament, life_span, image_url, updated_at)
        VALUES (%s, %s, %s, %s, %s, %s, %s)
        ON CONFLICT (id) DO UPDATE SET
            name = EXCLUDED.name,
            origin = EXCLUDED.origin,
            temperament = EXCLUDED.temperament,
            life_span = EXCLUDED.life_span,
            image_url = EXCLUDED.image_url,
            updated_at = EXCLUDED.updated_at;
        """
        
        for cat in cat_data:
            cursor.execute(upsert_sql, (
                cat['id'],
                cat['name'],
                cat['origin'],
                cat['temperament'],
                cat['life_span'],
                cat['image_url'],
                datetime.now()
            ))
            
            # Download image
            os.makedirs('data/images', exist_ok=True)
            image_path = f"data/images/{cat['id']}.jpg"
            download_image(cat['image_url'], image_path)

def save_cat_data(cat_data):
    """Main function to save cat data"""
    conn = None
    try:
        conn = psycopg2.connect(
            dbname=os.getenv('POSTGRES_DB', 'cat_db'),
            user=os.getenv('POSTGRES_USER', 'postgres'),
            password=os.getenv('POSTGRES_PASSWORD', 'postgres'),
            host=os.getenv('POSTGRES_HOST', 'localhost'),
            port=os.getenv('POSTGRES_PORT', '5432')
        )
        
        create_table(conn)
        save_to_database(conn, cat_data)
        conn.commit()
        print(f"Successfully saved {len(cat_data)} cat breeds to database")
        
    except Exception as e:
        print(f" Database error: {e}")
        if conn:
            conn.rollback()
    finally:
        if conn:
            conn.close()

if __name__ == "__main__":
    from crawl import crawl_cat_breeds
    from src.transform import transform_cat_data
    
    print("Starting cat data pipeline...")
    raw_data = crawl_cat_breeds()
    transformed_data = transform_cat_data(raw_data)
    save_cat_data(transformed_data)
    print("Pipeline completed!")