import requests
import json
from urllib.parse import urljoin

BASE_URL = "https://api.thecatapi.com/v1/"
BREEDS_ENDPOINT = "breeds"
DEFAULT_IMAGE_URL = "https://cdn2.thecatapi.com/images/aae.jpg"

def crawl_cat_breeds():
    """Crawl cat breeds data from The Cat API"""
    url = urljoin(BASE_URL, BREEDS_ENDPOINT)
    headers = {'User-Agent': 'CatBreedCrawler/1.0'}
    
    try:
        response = requests.get(url, headers=headers, timeout=30)
        response.raise_for_status()
        
        breeds_data = response.json()
        extracted_data = []
        
        for breed in breeds_data:
            # Build image URL
            image_url = DEFAULT_IMAGE_URL
            if breed.get('reference_image_id'):
                image_url = f"https://cdn2.thecatapi.com/images/{breed['reference_image_id']}.jpg"
            
            extracted_data.append({
                'id': breed.get('id', '').strip(),
                'name': breed.get('name', '').strip(),
                'origin': breed.get('origin', '').strip(),
                'temperament': breed.get('temperament', '').strip(),
                'life_span': breed.get('life_span', '').strip(),
                'image_url': image_url,
            })
            
        return extracted_data
        
    except requests.exceptions.RequestException as e:
        print(f"Request failed: {e}")
        return []
    except (json.JSONDecodeError, AttributeError) as e:
        print(f"Data parsing error: {e}")
        return []

if __name__ == "__main__":
    data = crawl_cat_breeds()
    print(json.dumps(data[:5], indent=2))  # Print first 2 items for preview