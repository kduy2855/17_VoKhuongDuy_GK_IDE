import re

DEFAULT_IMAGE_URL = "https://cdn2.thecatapi.com/images/aae.jpg"

def clean_text(text):
    """Clean and standardize text data"""
    if not isinstance(text, str):
        return ""
    # Remove extra whitespace and special characters
    text = re.sub(r'\s+', ' ', text).strip()
    return text

def transform_cat_data(cat_data):
    """Transform raw cat data into cleaned structured format"""
    transformed_data = []
    
    for cat in cat_data:
        # Clean and split temperament into list
        temperament = clean_text(cat.get('temperament', ''))
        temperament_list = [t.strip() for t in temperament.split(',')] if temperament else []
        
        # Clean lifespan (remove non-numeric characters)
        life_span = re.sub(r'[^\d\s-]', '', cat.get('life_span', ''))
        
        # Handle image URL
        image_url = cat.get('image_url', '')
        if not image_url or 'default' in image_url.lower():
            image_url = DEFAULT_IMAGE_URL
            
        transformed_data.append({
            'id': clean_text(cat.get('id', '')),
            'name': clean_text(cat.get('name', '')),
            'origin': clean_text(cat.get('origin', '')),
            'temperament': temperament_list,
            'life_span': life_span.strip(),
            'image_url': image_url
        })
    
    return transformed_data

if __name__ == "__main__":
    from crawl import crawl_cat_breeds
    raw_data = crawl_cat_breeds()
    transformed_data = transform_cat_data(raw_data)
    
    # Print sample transformed data
    print("=== TRANSFORMED CAT DATA ===")
    for i, cat in enumerate(transformed_data[:3], 1):
        print(f"\nCat #{i}:")
        print(f"Name: {cat['name']}")
        print(f"Origin: {cat['origin']}")
        print(f"Temperament: {', '.join(cat['temperament'])}")
        print(f"Life Span: {cat['life_span']} years")
        print(f"Image URL: {cat['image_url']}")