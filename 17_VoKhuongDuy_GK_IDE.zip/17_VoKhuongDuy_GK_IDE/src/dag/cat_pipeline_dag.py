from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
from src.crawl import crawl_cat_breeds
from src.transform import transform_cat_data
from src.save import save_cat_data

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'retries': 2,
    'retry_delay': timedelta(minutes=5),
    'email_on_failure': False,
}

def run_crawl():
    return crawl_cat_breeds()

def run_transform(**context):
    raw_data = context['task_instance'].xcom_pull(task_ids='crawl_cat')
    return transform_cat_data(raw_data)

def run_save(**context):
    transformed_data = context['task_instance'].xcom_pull(task_ids='transform_cat')
    save_cat_data(transformed_data)

with DAG(
    dag_id='cat_breed_pipeline',
    default_args=default_args,
    description='Daily pipeline to collect cat breed information',
    schedule_interval='0 9 * * *',  # 9AM daily
    start_date=datetime(2024, 1, 1),
    catchup=False,
    tags=['cats', 'etl'],
) as dag:

    crawl_task = PythonOperator(
        task_id='crawl_cat',
        python_callable=run_crawl,
    )

    transform_task = PythonOperator(
        task_id='transform_cat',
        python_callable=run_transform,
    )

    save_task = PythonOperator(
        task_id='save_cat',
        python_callable=run_save,
    )

    crawl_task >> transform_task >> save_task